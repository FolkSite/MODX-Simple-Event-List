# MODX-Simple-Event-List
Drop-in Simple Event Lists for Upcoming or Past Events.

https://github.com/dubrod/MODX-Simple-Event-List
